#ifndef XML_REGEXP_H_PRIVATE__
#define XML_REGEXP_H_PRIVATE__

#include <libxml/xmlautomata.h>

XML_HIDDEN void
xmlAutomataSetFlags(xmlAutomataPtr am, int flags);

#endif /* XML_REGEXP_H_PRIVATE__ */
