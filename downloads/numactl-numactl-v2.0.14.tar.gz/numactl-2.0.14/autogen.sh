#!/bin/sh

set -e

autoreconf --install --symlink
