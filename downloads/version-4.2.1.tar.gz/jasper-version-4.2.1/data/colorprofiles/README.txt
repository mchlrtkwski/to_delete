This directory contains a number of ICC color profiles.

Some of the more important profiles include:

sgray.icm
	JPEG-2000 JP2 standard gray enumerated color space
	This profile was provided by Scott Houchin of Kodak.

srgb.icm
	JPEG-2000 JP2 standard RGB (i.e., sRGB) enumerated color space
	This profile was provided by Scott Houchin of Kodak.

sycc.icm
	JPEG-2000 JP2 standard YCC enumerated color space
	This profile was provided by Jack Holm of Hewlett Packard.

A number of other profiles in this directory were provided by Scott
Houchin of Kodak.
